### docker-ci-bchunlimited

Docker files to create an image to use in GitLab CI
