How to do a gitian build is documented in [Gitian Build](/doc/gitian-building-bu.md)
